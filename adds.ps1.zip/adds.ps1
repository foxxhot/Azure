﻿Configuration adds
{
   param
    (
        [Parameter(Mandatory)]
        [PSCredential]$safemodeAdministratorCred,
        [Parameter(Mandatory)]
        [PSCredential]$NewADUserCred,
        [Parameter(Mandatory)]
        [PSCredential]$domainCred
    )

    Import-DscResource -ModuleName xActiveDirectory

    $DomainName = "feast.contoso.com"
    $RetryCount = 20
    $RetryIntervalSec = 30

    Node localhost
    {
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }
		WindowsFeature ADAdminCenter 
        { 
            Ensure = "Present" 
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
			
        }
		WindowsFeature ADDSTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
			
        } 
        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $domainCred
            SafemodeAdministratorPassword = $safemodeAdministratorCred
            
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $domainCred
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xADDomain]FirstDS"
        }

        xADUser FirstUser
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $domainCred
            UserName = "dummy"
            Password = $NewADUserCred
            Ensure = "Present"
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
	        ConfigurationMode = 'ApplyOnly'
        }
    }
}


