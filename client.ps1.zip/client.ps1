﻿Configuration client
{
   param
    (
        [Parameter(Mandatory)]
        [PSCredential]$domainCred

    )
    

    Import-DscResource -ModuleName xComputerManagement

    $DomainName = "feast.contoso.com"
    
    Node localhost
    {
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($domainCred.UserName)", $domainCred.Password)
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
	        ConfigurationMode = 'ApplyOnly'
        }
    }
}