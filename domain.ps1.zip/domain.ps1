﻿Configuration domain
{
   param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$safemodeAdministratorCred,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$domainCred,

        [Parameter(Mandatory)]
        [String]$MachineName

    )

    Import-DscResource -ModuleName xActiveDirectory

    Node $MachineName
    {
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }
        xADDomain FirstDS
        {
            DomainName = "dsc-test.contoso.com"
            DomainAdministratorCredential = $domainCred
            SafemodeAdministratorPassword = $safemodeAdministratorCred
            
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = "dsc-test.contoso.com"
            DomainUserCredential = $domainCred
            RetryCount = 20
            RetryIntervalSec = 30
            DependsOn = "[xADDomain]FirstDS"
        }
    }
}


