﻿Configuration domain1
{
   param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$safemodeAdministratorCred,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$domainCred

    )

    Import-DscResource -ModuleName xActiveDirectory

    $DomainName = "dsc-test.contoso.com"
    $RetryCount = 20
    $RetryIntervalSec = 30
    $safemodeAdministratorCred_encrypt = New-Object System.Management.Automation.PSCredential ($safemodeAdministratorCred.UserName, $safemodeAdministratorCred.Password)
    $domainCred_encrypt = New-Object System.Management.Automation.PSCredential ($domainCred.UserName, $domainCred.Password)

    Node localhost
    {
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }
        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $domainCred_encrypt
            SafemodeAdministratorPassword = $safemodeAdministratorCred_encrypt
            
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $domainCred_encrypt
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xADDomain]FirstDS"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
	        ConfigurationMode = 'ApplyOnly'
        }
    }
}


