﻿Configuration domain1
{
   param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$safemodeAdministratorCred,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$domainCred,

        [Parameter(Mandatory)]
        [String]$MachineName

    )

    Import-DscResource -ModuleName xActiveDirectory

    $DomainName = "dsc-test.contoso.com"
    $RetryCount = 20
    $RetryIntervalSec = 30

    Node $MachineName
    {
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }
        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $domainCred
            SafemodeAdministratorPassword = $safemodeAdministratorCred
            
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $domainCred
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xADDomain]FirstDS"
        }
    }
}


