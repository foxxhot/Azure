﻿Configuration dsctest
{
    Node localhost
    {
        WindowsFeature IIS
        {
            Ensure               = "Present"
            Name                 = "Web-Server"
        } 

		Script script1
		{
      	    SetScript =  { 
			    new-item D:\dsctest -ItemType directory
            }
            GetScript =  { @{} }
            TestScript = { $false}
			DependsOn = "[WindowsFeature]IIS"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
	        ConfigurationMode = 'ApplyOnly'
        }
    }
}


